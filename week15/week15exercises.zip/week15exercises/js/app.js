// #10 Set up an Angular app module and add a controller to that module
var app = angular.module("myApp", []);
